package Bai14;
public class InvalidFullNameException extends Exception {
    public InvalidFullNameException(String message) {
        super(message);
    }
}
